#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%#
#                      DATAPACK INFO                     #
# ------------------------------------------------------ #
#     Author: GenMode                                    #
#     URL: https://github.com/GenMode/Minecraft/wiki     #
#                                                        #
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%#

# Advancements
execute as @s[advancements={better_babies:player_interacted_with_entity/entities={pet_mob=true}}] \
    as @e[type=#better_babies:pets, predicate=better_babies:misc/track, distance=..6] at @s \
    run function better_babies:entity/pet

# Close
advancement revoke @s only better_babies:player_interacted_with_entity/entities