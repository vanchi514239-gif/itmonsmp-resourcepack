#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%#
#                      DATAPACK INFO                     #
# ------------------------------------------------------ #
#     Author: GenMode                                    #
#     URL: https://github.com/GenMode/Minecraft/wiki     #
#                                                        #
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%#

# Advancements
execute as @s[advancements={better_babies:tick/custom_mob={tempt_wolf=true}}] \
    as @n[type=minecraft:wolf,  \
        tag=entity.better_babies.mob, \
        predicate=data_api:flags/on_ground, predicate=better_babies:misc/track_begging_false, \
        distance=..6] \
    on passengers \
    run data modify entity @s item.components."minecraft:custom_data".model.begging set value true
execute as @s[advancements={better_babies:tick/custom_mob={tempt_wolf=true}}] \
    run rotate @e[type=minecraft:wolf, \
            tag=entity.better_babies.mob, \
            distance=..6, \
            predicate=data_api:flags/on_ground, predicate=!data_api:flags/is_moving, predicate=better_babies:misc/track_begging, \
            sort=random, limit=1] \
        facing entity @s

# Close
advancement revoke @s only better_babies:tick/custom_mob