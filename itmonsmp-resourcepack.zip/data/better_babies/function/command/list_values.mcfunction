#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%#
#                      DATAPACK INFO                     #
# ------------------------------------------------------ #
#     Author: GenMode                                    #
#     URL: https://github.com/GenMode/Minecraft/wiki     #
#                                                        #
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%#

# Initialize
$data modify storage gamerule:private toggle_mob.query set value {translate: "[%s: %s]", with: [{color: "aqua", "text": "$(id)"}]}

# Prepare Data
$execute if data storage better_babies:store entities[{id: "$(id)", toggle: false}] run data modify storage gamerule:private toggle_mob.query.with append value {color: "red", hover_event: {action: "show_text"}, translate: "options.off"}
$execute if data storage better_babies:store entities[{id: "$(id)", toggle: false}] run data modify storage gamerule:private toggle_mob.query.with[1].hover_event.value set value "false"
$execute if data storage better_babies:store entities[{id: "$(id)", toggle: true}] run data modify storage gamerule:private toggle_mob.query.with append value {color: "green", hover_event: {action: "show_text"}, translate: "options.on"}
$execute if data storage better_babies:store entities[{id: "$(id)", toggle: true}] run data modify storage gamerule:private toggle_mob.query.with[1].hover_event.value set value "true"

# Modify Data
$execute unless data storage better_babies:store entities[{id: "$(id)"}].type run data modify storage gamerule:private toggle_mob.query set value false
$execute unless data storage better_babies:store entities[{id: "$(id)"}].default.model run data modify storage gamerule:private toggle_mob.query set value false
$execute if data storage gamerule:private toggle_mob{query: false} run data remove storage better_babies:store entities[{id: "$(id)"}]

# Output Data
execute unless data storage gamerule:private toggle_mob{query: false} run data modify storage gamerule:private toggle_mob.feedback append from storage gamerule:private toggle_mob.query
execute unless data storage gamerule:private toggle_mob{query: false} if data storage gamerule:private toggle_mob.list[1] run data modify storage gamerule:private toggle_mob.feedback append value ", "

# Close
data remove storage gamerule:private toggle_mob.list[0]
execute if data storage gamerule:private toggle_mob.list[0] run function better_babies:command/list_values with storage gamerule:private toggle_mob.list[0]