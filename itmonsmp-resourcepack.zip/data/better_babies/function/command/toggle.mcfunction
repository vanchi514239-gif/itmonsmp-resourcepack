#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%#
#                      DATAPACK INFO                     #
# ------------------------------------------------------ #
#     Author: GenMode                                    #
#     URL: https://github.com/GenMode/Minecraft/wiki     #
#                                                        #
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%#

# Modify Data
$execute if data storage gamerule:private toggle_mob{set: "false"} as @s[type=$(type), tag=entity.better_babies.mob] run function better_babies:entity/remove
$execute if data storage gamerule:private toggle_mob{set: "true"} run tag @s[type=$(type)] remove init.better_babies

# Trader Llama
execute if data storage gamerule:private toggle_mob{set: "true"} \
    if data storage gamerule:private toggle_mob{id: "baby_llama"} \
    run tag @s[type=minecraft:trader_llama] remove init.better_babies