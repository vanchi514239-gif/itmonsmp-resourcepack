#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%#
#                      DATAPACK INFO                     #
# ------------------------------------------------------ #
#     Author: GenMode                                    #
#     URL: https://github.com/GenMode/Minecraft/wiki     #
#                                                        #
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%#

# Initialize
execute as @s[tag=!private.better_babies.init] on passengers run kill @s
effect clear @s minecraft:invisibility

# Function
function data_api:command/modify_data/import {\
    from: {entity_id: "@s"}, \
    to: {\
        nbt: "loadup.entity.id", \
        target: "better_babies:private", \
        type: "storage"}}
function better_babies:entity/baby_mob/set_data with storage better_babies:private loadup.entity

# Modify Data
execute on passengers unless data entity @s item.components."minecraft:custom_data".custom_entity_data.track[0] run data remove entity @s item.components."minecraft:custom_data".custom_entity_data.track
execute unless data entity @s Passengers run function better_babies:entity/remove

# Close
data remove storage better_babies:private loadup