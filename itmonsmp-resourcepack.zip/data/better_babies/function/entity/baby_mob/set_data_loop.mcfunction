#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%#
#                      DATAPACK INFO                     #
# ------------------------------------------------------ #
#     Author: GenMode                                    #
#     URL: https://github.com/GenMode/Minecraft/wiki     #
#                                                        #
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%#

# Function
execute if data storage better_babies:private loadup.array[0].context run function better_babies:entity/baby_mob/set_model_context with storage better_babies:private loadup.array[0]
execute unless data storage better_babies:private loadup.array[0].context run function better_babies:entity/baby_mob/set_model with storage better_babies:private loadup.array[0]

# Modify Data
data remove storage better_babies:private loadup.array[0]

# Close
execute if data storage better_babies:private loadup.array[0] run function better_babies:entity/baby_mob/set_data_loop