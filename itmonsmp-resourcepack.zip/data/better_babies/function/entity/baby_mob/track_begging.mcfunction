#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%#
#                      DATAPACK INFO                     #
# ------------------------------------------------------ #
#     Author: GenMode                                    #
#     URL: https://github.com/GenMode/Minecraft/wiki     #
#                                                        #
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%#

# Modify Data
execute unless entity @p[distance=..6, predicate=better_babies:misc/holding_wolf_temptable] on passengers run data modify entity @s item.components."minecraft:custom_data".model.begging set value false
execute as @s[predicate=!data_api:flags/on_ground] on passengers run data modify entity @s item.components."minecraft:custom_data".model.begging set value false