#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%#
#                      DATAPACK INFO                     #
# ------------------------------------------------------ #
#     Author: GenMode                                    #
#     URL: https://github.com/GenMode/Minecraft/wiki     #
#                                                        #
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%#

# Modify Data (angry)
execute as @s[nbt=!{AngerTime: 0}] on passengers \
    if data entity @s item.components."minecraft:custom_data".model.angry \
    run data modify entity @s item.components."minecraft:custom_data".model.angry set value true
execute as @s[nbt=!{AngerTime: 0}] run function better_babies:entity/baby_mob/face_target with entity @s
execute as @s[nbt={AngerTime: 0}] on passengers \
    if data entity @s item.components."minecraft:custom_data".model.angry \
    run data modify entity @s item.components."minecraft:custom_data".model.angry set value false