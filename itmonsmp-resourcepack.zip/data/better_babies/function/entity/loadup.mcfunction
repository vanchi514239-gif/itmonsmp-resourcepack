#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%#
#                      DATAPACK INFO                     #
# ------------------------------------------------------ #
#     Author: GenMode                                    #
#     URL: https://github.com/GenMode/Minecraft/wiki     #
#                                                        #
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%#

# Initialize
execute as @s[type=!minecraft:trader_llama, tag=!data.entity] \
    if predicate data_api:flags/is_baby \
    run function better_babies:entity/baby_mob/loadup

# Function
execute as @s[type=minecraft:trader_llama, tag=!data.entity] \
    if predicate data_api:flags/is_baby \
    if data storage better_babies:store entities[{id: "baby_llama", toggle: true}] \
    run function better_babies:entity/swap_base

# Close
tag @s add init.better_babies