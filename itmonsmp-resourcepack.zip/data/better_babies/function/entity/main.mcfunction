#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%#
#                      DATAPACK INFO                     #
# ------------------------------------------------------ #
#     Author: GenMode                                    #
#     URL: https://github.com/GenMode/Minecraft/wiki     #
#                                                        #
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%#

# Initialize
execute as @n[type=#better_babies:initialize, tag=entity.better_babies.mob, predicate=!better_babies:misc/update_passenger] run tag @s remove init.better_babies

# If Predicate
execute as @n[type=#better_babies:initialize, tag=entity.better_babies.mob, nbt={Age: 0}] run function better_babies:entity/remove

# Modify Data
execute as @n[type=#better_babies:pets, tag=entity.better_babies.mob, predicate=better_babies:misc/track_has_owner] if data entity @s Owner on passengers run data modify entity @s item.components."minecraft:custom_data".model.has_owner set value true
execute as @n[type=#better_babies:initialize, tag=entity.better_babies.mob, predicate=better_babies:misc/tracking] run function better_babies:entity/baby_mob/tracking
execute as @e[type=minecraft:wolf, tag=entity.better_babies.mob, predicate=better_babies:misc/track_begging, sort=random, limit=10] at @s run function better_babies:entity/baby_mob/track_begging
execute as @e[type=minecraft:bee, tag=entity.better_babies.mob] run data modify entity @s Motion[1] set value -0.09