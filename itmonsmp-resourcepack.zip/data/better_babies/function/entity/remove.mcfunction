#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%#
#                      DATAPACK INFO                     #
# ------------------------------------------------------ #
#     Author: GenMode                                    #
#     URL: https://github.com/GenMode/Minecraft/wiki     #
#                                                        #
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%#

# Initialize
tag @s remove entity.better_babies.mob

# Modify Data
effect clear @s minecraft:invisibility
execute on passengers run kill @s
data modify entity @s[tag=track.better_babies.untame] Tame set value false

# Modify Tags
tag @s remove private.data_api.ping
tag @s remove track.better_babies.begging
tag @s remove track.better_babies.angry
tag @s remove track.better_babies.tame
tag @s remove track.better_babies.untame

# Close
tag @s remove entity.data_api.custom_mob
execute as @s[type=minecraft:llama, tag=ping.better_babies.swapped] at @s run function better_babies:entity/swap_base