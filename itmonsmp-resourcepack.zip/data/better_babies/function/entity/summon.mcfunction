#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%#
#                      DATAPACK INFO                     #
# ------------------------------------------------------ #
#     Author: GenMode                                    #
#     URL: https://github.com/GenMode/Minecraft/wiki     #
#                                                        #
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%#

# Initialize
$data modify entity @s {} merge value {Tags: $(Tags)}
$execute unless entity @n[type=#minecraft:display_entities, tag=private.better_babies.init] at @s \
    run summon minecraft:item_display ~ ~ ~ {\
        item_display: "fixed", \
        teleport_duration: 3, \
        Tags: ["data.entity", "entity.better_babies.model", "private.better_babies.init"], \
        transformation: $(transformation), }

# Custom Data
$data modify entity @n[type=#minecraft:display_entities, tag=private.better_babies.init] item set value {\
    id: "$(item)", \
    components: {\
        "minecraft:custom_data": {\
            custom_entity_data: {animate: $(animate), \
            original_name: "null", \
            track: $(track)}, \
            model: $(states)}, \
        "minecraft:item_model": "$(model)", \
        "minecraft:item_name": {translate: "$(name)"}}}

# Close
tellraw @s[type=minecraft:player] {\
    color: "light_purple", \
    translate: "commands.summon.success", \
    with: [{selector: "@n[type=!#minecraft:display_entities, tag=private.better_babies.init]"}]}
ride @n[type=#minecraft:display_entities, tag=private.better_babies.init] mount @n[type=!#minecraft:display_entities, tag=private.better_babies.init]
tag @e remove private.better_babies.init