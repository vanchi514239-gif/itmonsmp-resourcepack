#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%#
#                      DATAPACK INFO                     #
# ------------------------------------------------------ #
#     Author: GenMode                                    #
#     URL: https://github.com/GenMode/Minecraft/wiki     #
#                                                        #
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%#

# Initialize
tag @s[type=minecraft:trader_llama] add ping.better_babies.swapped

# Summon
execute as @s[type=minecraft:llama] run summon minecraft:trader_llama ~ ~ ~ {Tags: ["private.better_babies.target"]}
execute as @s[type=minecraft:trader_llama] run summon minecraft:llama ~ ~ ~ {Tags: ["private.better_babies.target"]}

# Modify Data
tag @s[type=minecraft:llama] remove ping.better_babies.swapped
data modify entity @n[tag=private.better_babies.target] {} merge from entity @s {}

# Close
function data_api:entity/remove
tag @e remove private.better_babies.target