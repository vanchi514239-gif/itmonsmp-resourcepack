#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%#
#                      DATAPACK INFO                     #
# ------------------------------------------------------ #
#     Author: GenMode                                    #
#     URL: https://github.com/GenMode/Minecraft/wiki     #
#                                                        #
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%#

# Tellraw
$tellraw @a {\
    bold: true, \
    color: "red", \
    translate: "WARNING: %s v%s is not installed. \nSome features in %s may not work properly without it", \
    with: [\
        {translate: "$(dependency)", underlined: true}, \
        "$(api_build)", \
        {translate: "$(name)", underlined: true}]}