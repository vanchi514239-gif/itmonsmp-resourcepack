#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%#
#                      DATAPACK INFO                     #
# ------------------------------------------------------ #
#     Author: GenMode                                    #
#     URL: https://github.com/GenMode/Minecraft/wiki     #
#                                                        #
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%#
# Tracking: 3cpt

# Initialize
execute as @n[type=#better_babies:initialize, tag=!init.better_babies] at @s run function better_babies:entity/loadup

# Entity
execute if entity @n[type=#better_babies:initialize, tag=entity.better_babies.mob] run function better_babies:entity/main
execute as @n[type=#better_babies:pets, predicate=better_babies:misc/track] run function better_babies:entity/pet