#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%#
#                      DATAPACK INFO                     #
# ------------------------------------------------------ #
#     Author: GenMode                                    #
#     URL: https://github.com/GenMode/Minecraft/wiki     #
#                                                        #
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%#

# Initialize
$data modify storage gamerule:private toggle_mob set value {id: '$(id)', set: '$(set)'}

# Validate
data modify storage gamerule:private toggle_mob.inputs set value [\
    {pass: 0, values: ["false", "0", "0b"]}, \
    {pass: 1, values: ["feedback", "?", "info", "list", "query"]}, \
    {pass: 2, values: ["reset", "default"]}, \
    {pass: 0, values: ["true", "1", "1b"]}]
$data modify storage gamerule:private toggle_mob.set set from storage gamerule:private toggle_mob.inputs[{values: ["$(set)"]}].values[0]
$data modify storage gamerule:private toggle_mob.pass set from storage gamerule:private toggle_mob.inputs[{values: ["$(set)"]}].pass
execute if data storage gamerule:private toggle_mob{id: "all"} run data modify storage gamerule:private toggle_mob.pass set value 3
execute unless data storage gamerule:private toggle_mob.pass run data modify storage gamerule:private toggle_mob.set set value "feedback"

# Prepare Data
execute if data storage gamerule:private toggle_mob{pass: 3} run data modify storage gamerule:private toggle_mob.list set from storage better_babies:store entities
execute if data storage gamerule:private toggle_mob{pass: 3} run data modify storage gamerule:private toggle_mob.feedback set value [""]

# Settings (set)
$execute if data storage gamerule:private toggle_mob{pass: 0} if data storage gamerule:private toggle_mob{set: "false"} run data modify storage better_babies:store entities[{id: "$(id)"}].toggle set value false
$execute if data storage gamerule:private toggle_mob{pass: 0} if data storage gamerule:private toggle_mob{set: "true"} run data modify storage better_babies:store entities[{id: "$(id)"}].toggle set value true
$execute if data storage gamerule:private toggle_mob{pass: 0} run tellraw @s {color: "light_purple", translate: "commands.gamerule.set", with: ["better_babies/($(id))", {nbt: "toggle_mob.set", storage: "gamerule:private"}]}
execute if data storage gamerule:private toggle_mob{pass: 3} if data storage gamerule:private toggle_mob{set: "false"} run data modify storage better_babies:store entities[].toggle set value false
execute if data storage gamerule:private toggle_mob{pass: 3} if data storage gamerule:private toggle_mob{set: "true"} run data modify storage better_babies:store entities[].toggle set value true
execute if data storage gamerule:private toggle_mob{pass: 3} if data storage gamerule:private toggle_mob{set: "false"} run tellraw @s {color: "light_purple", translate: "commands.gamerule.set", with: ["better_babies/(#ALL)", {nbt: "toggle_mob.set", storage: "gamerule:private"}]}
execute if data storage gamerule:private toggle_mob{pass: 3} if data storage gamerule:private toggle_mob{set: "true"} run tellraw @s {color: "light_purple", translate: "commands.gamerule.set", with: ["better_babies/(#ALL)", {nbt: "toggle_mob.set", storage: "gamerule:private"}]}
# Settings (feedback)
$execute if data storage gamerule:private toggle_mob{pass: 1} if data storage better_babies:store entities[{id: "$(id)", toggle: false}] run tellraw @s {color: "light_purple", translate: "commands.gamerule.query", with: ["better_babies/($(id))", "false"]}
$execute if data storage gamerule:private toggle_mob{pass: 1} if data storage better_babies:store entities[{id: "$(id)", toggle: true}] run tellraw @s {color: "light_purple", translate: "commands.gamerule.query", with: ["better_babies/($(id))", "true"]}
execute if data storage gamerule:private toggle_mob{pass: 3} if data storage gamerule:private toggle_mob{set: "feedback"} run function better_babies:command/list_values with storage gamerule:private toggle_mob.list[0]
execute if data storage gamerule:private toggle_mob{pass: 3} if data storage gamerule:private toggle_mob{set: "feedback"} run tellraw @s {bold: true, color: "light_purple", translate: "---------- < %s > ----------", with: [{translate: "mco.configure.world.settings.title"}]}
execute if data storage gamerule:private toggle_mob{pass: 3} if data storage gamerule:private toggle_mob{set: "feedback"} run tellraw @s {interpret: true, nbt: "toggle_mob.feedback", storage: "gamerule:private"}
execute if data storage gamerule:private toggle_mob{pass: 3} if data storage gamerule:private toggle_mob{set: "feedback"} run playsound minecraft:block.note_block.bit player @s ~ ~ ~ 1 2
# Settings (reset)
$execute if data storage gamerule:private toggle_mob{pass: 2} run function gamerule:better_babies {id: "$(id)", set: "true"}
execute if data storage gamerule:private toggle_mob{pass: 3} if data storage gamerule:private toggle_mob{set: "reset"} run function gamerule:better_babies {id: "all", set: "true"}

# Close
$execute as @e[type=#better_babies:initialize] if data storage gamerule:private toggle_mob{pass: 0} if predicate data_api:flags/is_baby run function better_babies:command/toggle with storage better_babies:store entities[{id: "$(id)"}]
execute as @e[type=#better_babies:initialize] if data storage gamerule:private toggle_mob{pass: 3} if data storage gamerule:private toggle_mob{set: "false"} if predicate data_api:flags/is_baby run function better_babies:command/toggle {type: "#better_babies:initialize"}
execute as @e[type=#better_babies:initialize] if data storage gamerule:private toggle_mob{pass: 3} if data storage gamerule:private toggle_mob{set: "true"} if predicate data_api:flags/is_baby run function better_babies:command/toggle {type: "#better_babies:initialize"}
data remove storage gamerule:private toggle_mob