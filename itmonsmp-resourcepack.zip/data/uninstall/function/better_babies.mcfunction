#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%#
#                      DATAPACK INFO                     #
# ------------------------------------------------------ #
#     Author: GenMode                                    #
#     URL: https://github.com/GenMode/Minecraft/wiki     #
#                                                        #
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%#

# Initialize
execute as @e[type=#better_babies:initialize, tag=entity.better_babies.mob] run function better_babies:entity/remove
tag @e[type=#better_babies:initialize] remove init.better_babies

# Objectives
scoreboard objectives remove better_babies

# Storage
data remove storage better_babies:store entities

# Disable
datapack disable "file/better_babies"
datapack disable "file/better_babies (modified)"
datapack disable "file/better_babies (modified).zip"
datapack disable "file/better_babies.zip"
datapack disable "file/better_babies-datapack"
datapack disable "file/better_babies-datapack.zip"

# Close
tellraw @a {color: "red", translate: "%s has been uninstalled. You may now remove the file", with: [{translate: "Better Babies"}]}